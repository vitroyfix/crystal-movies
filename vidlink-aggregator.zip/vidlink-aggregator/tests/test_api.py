import pytest
from tests.conftest import client  # noqa: F401  – fixture import


@pytest.mark.asyncio
async def test_resolve_movie(monkeypatch, client):
    """Full happy-path for a movie resolve."""

    # ── Patch cache: always miss, set is a no-op ──────────────────────
    monkeypatch.setattr("services.cache.redis.RedisCache.get", lambda *_: None)
    monkeypatch.setattr(
        "services.cache.redis.RedisCache.set",
        lambda *args, **kwargs: None,
    )

    # ── Patch TMDB ────────────────────────────────────────────────────
    async def fake_get_movie(tmdb_id):
        return {"title": "The Matrix", "year": "1999", "tmdb_id": tmdb_id, "type": "movie"}

    monkeypatch.setattr("services.metadata.tmdb.TMDB.get_movie", fake_get_movie)

    # ── Patch scrapers ────────────────────────────────────────────────
    async def fake_scrape(title, year):
        return [{"provider": "demo", "quality": "1080p", "url": "https://example.com/stream.m3u8"}]

    monkeypatch.setattr("services.scraper.base.ScraperFactory.scrape", fake_scrape)

    # ── Patch transcoder ──────────────────────────────────────────────
    async def fake_transcode(sources, s3):
        return "https://cdn.example.com/hls/master.m3u8"

    monkeypatch.setattr("api.router.generate_and_upload_master", fake_transcode)

    resp = await client.post("/api/resolve", json={"id": 603, "type": "movie"})
    assert resp.status_code == 200

    data = resp.json()
    assert data["metadata"]["title"] == "The Matrix"
    assert data["master_playlist"] == "https://cdn.example.com/hls/master.m3u8"
    assert data["sources"][0]["provider"] == "demo"


@pytest.mark.asyncio
async def test_resolve_returns_404_when_no_sources(monkeypatch, client):
    """Should raise 404 when all scrapers return empty."""

    monkeypatch.setattr("services.cache.redis.RedisCache.get", lambda *_: None)
    monkeypatch.setattr("services.cache.redis.RedisCache.set", lambda *a, **k: None)

    async def fake_get_movie(tmdb_id):
        return {"title": "Unknown", "year": "2000", "tmdb_id": tmdb_id, "type": "movie"}

    monkeypatch.setattr("services.metadata.tmdb.TMDB.get_movie", fake_get_movie)

    async def empty_scrape(title, year):
        return []

    monkeypatch.setattr("services.scraper.base.ScraperFactory.scrape", empty_scrape)

    resp = await client.post("/api/resolve", json={"id": 1, "type": "movie"})
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_resolve_cache_hit(monkeypatch, client):
    """Should return cached data without hitting scrapers."""

    cached_data = {
        "metadata": {"title": "Cached Movie", "year": "2020"},
        "sources": [{"provider": "demo", "quality": "720p", "url": "https://example.com/c.m3u8"}],
        "master_playlist": "https://cdn.example.com/cached/master.m3u8",
    }

    async def fake_cache_get(self, key):
        return cached_data

    monkeypatch.setattr("services.cache.redis.RedisCache.get", fake_cache_get)

    scrape_called = []

    async def should_not_be_called(title, year):
        scrape_called.append(True)
        return []

    monkeypatch.setattr("services.scraper.base.ScraperFactory.scrape", should_not_be_called)

    resp = await client.post("/api/resolve", json={"id": 99, "type": "movie"})
    assert resp.status_code == 200
    assert not scrape_called, "Scraper should not be called on a cache hit"
    assert resp.json()["metadata"]["title"] == "Cached Movie"


@pytest.mark.asyncio
async def test_invalid_type_rejected(client):
    """type field must be movie | tv | anime."""
    resp = await client.post("/api/resolve", json={"id": 1, "type": "podcast"})
    assert resp.status_code == 422
