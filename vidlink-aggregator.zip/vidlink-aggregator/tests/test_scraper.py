import pytest
from services.scraper.base import ScraperFactory


@pytest.mark.asyncio
async def test_scrape_factory_merges_results(monkeypatch):
    """ScraperFactory should merge sources from all scrapers."""

    async def fake_two_embedded(title, year):
        return [{"provider": "2embed", "quality": "1080p", "url": "https://a.m3u8"}]

    async def fake_autoembed(title, year):
        return [{"provider": "autoembed", "quality": "720p", "url": "https://b.m3u8"}]

    monkeypatch.setattr("services.scraper.two_embedded.TwoEmbedded.scrape", fake_two_embedded)
    monkeypatch.setattr("services.scraper.autoembed.AutoEmbed.scrape", fake_autoembed)

    results = await ScraperFactory.scrape("The Matrix", "1999")
    assert len(results) == 2
    providers = {r["provider"] for r in results}
    assert providers == {"2embed", "autoembed"}


@pytest.mark.asyncio
async def test_scrape_factory_tolerates_one_failure(monkeypatch):
    """If one scraper raises, the other's results should still be returned."""

    async def failing_scrape(title, year):
        raise RuntimeError("scraper exploded")

    async def working_scrape(title, year):
        return [{"provider": "autoembed", "quality": "720p", "url": "https://ok.m3u8"}]

    monkeypatch.setattr("services.scraper.two_embedded.TwoEmbedded.scrape", failing_scrape)
    monkeypatch.setattr("services.scraper.autoembed.AutoEmbed.scrape", working_scrape)

    results = await ScraperFactory.scrape("Inception", "2010")
    assert len(results) == 1
    assert results[0]["provider"] == "autoembed"


@pytest.mark.asyncio
async def test_scrape_factory_empty_when_all_fail(monkeypatch):
    """Should return empty list when all scrapers fail, not raise."""

    async def fail(title, year):
        raise RuntimeError("all down")

    monkeypatch.setattr("services.scraper.two_embedded.TwoEmbedded.scrape", fail)
    monkeypatch.setattr("services.scraper.autoembed.AutoEmbed.scrape", fail)

    results = await ScraperFactory.scrape("Unknown", "2000")
    assert results == []
