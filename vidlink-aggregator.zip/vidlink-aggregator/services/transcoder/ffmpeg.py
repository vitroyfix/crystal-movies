"""
FFmpeg transcoder.

Produces 1080p + 720p HLS variants from a source stream URL.
Output goes into out_dir as:
  out_dir/
    master.m3u8
    1080p/
      index.m3u8
      seg000.ts  seg001.ts  ...
    720p/
      index.m3u8
      seg000.ts  seg001.ts  ...
"""
import asyncio
import os

QUALITIES = [
    {"name": "1080p", "height": 1080, "bitrate": "5000k"},
    {"name": "720p",  "height": 720,  "bitrate": "2800k"},
]


async def transcode_to_hls(source_url: str, out_dir: str) -> str:
    """
    Transcode source_url to multi-bitrate HLS inside out_dir.
    Returns the absolute path of the master playlist.
    """
    os.makedirs(out_dir, exist_ok=True)

    # Run all quality variants in parallel
    await asyncio.gather(*[
        _encode_variant(source_url, q, out_dir)
        for q in QUALITIES
    ])

    master_path = os.path.join(out_dir, "master.m3u8")
    _write_master(master_path)
    return master_path


def _write_master(master_path: str):
    lines = ["#EXTM3U", "#EXT-X-VERSION:3"]
    for q in QUALITIES:
        bw = int(q["bitrate"].replace("k", "")) * 1000
        lines.append(
            f'#EXT-X-STREAM-INF:BANDWIDTH={bw},'
            f'RESOLUTION=1920x{q["height"]},'
            f'NAME="{q["name"]}"'
        )
        lines.append(f'{q["name"]}/index.m3u8')
    with open(master_path, "w") as f:
        f.write("\n".join(lines) + "\n")


async def _encode_variant(source_url: str, quality: dict, out_dir: str):
    variant_dir = os.path.join(out_dir, quality["name"])
    os.makedirs(variant_dir, exist_ok=True)
    playlist = os.path.join(variant_dir, "index.m3u8")
    segment_pattern = os.path.join(variant_dir, "seg%03d.ts")

    cmd = [
        "ffmpeg", "-y",
        "-i", source_url,
        "-vf", f"scale=-2:{quality['height']}",
        "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-b:v", quality["bitrate"],
        "-c:a", "aac", "-b:a", "128k", "-ac", "2",
        "-hls_time", "6",
        "-hls_list_size", "0",
        "-hls_segment_filename", segment_pattern,
        "-f", "hls",
        playlist,
    ]

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()

    if proc.returncode != 0:
        raise RuntimeError(
            f"FFmpeg failed for {quality['name']}: {stderr.decode()[-500:]}"
        )
