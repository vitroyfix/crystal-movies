import boto3
from botocore.config import Config


class S3Client:
    """
    Wraps boto3 for uploading HLS segments and playlists.
    Set use_r2=True + r2_account_id to use Cloudflare R2 instead of AWS S3.
    """

    def __init__(
        self,
        bucket: str,
        region: str,
        key: str,
        secret: str,
        use_r2: bool = False,
        r2_account_id: str = "",
    ):
        self.bucket = bucket
        self._region = region
        self._use_r2 = use_r2
        self._r2_account_id = r2_account_id

        endpoint = (
            f"https://{r2_account_id}.r2.cloudflarestorage.com"
            if use_r2
            else None
        )

        self._s3 = boto3.client(
            "s3",
            region_name=region,
            aws_access_key_id=key,
            aws_secret_access_key=secret,
            endpoint_url=endpoint,
            config=Config(signature_version="s3v4"),
        )

    def _public_url(self, s3_key: str) -> str:
        if self._use_r2:
            # R2 custom domain or public bucket URL
            return f"https://pub-{self._r2_account_id}.r2.dev/{s3_key}"
        return f"https://{self.bucket}.s3.{self._region}.amazonaws.com/{s3_key}"

    def upload_file(
        self,
        local_path: str,
        s3_key: str,
        content_type: str = "application/octet-stream",
    ) -> str:
        """Upload a local file and return its public URL."""
        self._s3.upload_file(
            local_path,
            self.bucket,
            s3_key,
            ExtraArgs={
                "ContentType": content_type,
                "ACL": "public-read",
            },
        )
        return self._public_url(s3_key)

    def upload_bytes(self, data: bytes, s3_key: str, content_type: str) -> str:
        """Upload raw bytes directly (no temp file needed)."""
        self._s3.put_object(
            Bucket=self.bucket,
            Key=s3_key,
            Body=data,
            ContentType=content_type,
            ACL="public-read",
        )
        return self._public_url(s3_key)
