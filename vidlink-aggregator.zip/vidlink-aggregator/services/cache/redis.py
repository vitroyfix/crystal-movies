import json
import aioredis


class RedisCache:
    """Async Redis wrapper — stores dicts as JSON strings."""

    def __init__(self, url: str):
        self._url = url
        self._client: aioredis.Redis | None = None

    async def connect(self):
        self._client = await aioredis.from_url(
            self._url, encoding="utf-8", decode_responses=True
        )

    async def get(self, key: str) -> dict | None:
        if not self._client:
            return None
        raw = await self._client.get(key)
        if raw is None:
            return None
        return json.loads(raw)

    async def set(self, key: str, value: dict, ttl: int = 3600):
        if not self._client:
            return
        await self._client.setex(key, ttl, json.dumps(value))

    async def delete(self, key: str):
        if not self._client:
            return
        await self._client.delete(key)

    async def close(self):
        if self._client:
            await self._client.close()
