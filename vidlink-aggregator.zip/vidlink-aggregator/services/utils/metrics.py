"""
Centralised Prometheus metric definitions.

Import from here everywhere so counters are never registered twice.
Prometheus raises CollectorRegistry errors if the same name is
registered more than once — a common bug when metrics are defined
in multiple modules.
"""
from prometheus_client import Counter, Histogram

REQUESTS = Counter(
    "api_requests_total",
    "Total API requests",
    ["endpoint"],
)

CACHE_HITS = Counter(
    "cache_hits_total",
    "Number of Redis cache hits",
)

CACHE_MISSES = Counter(
    "cache_misses_total",
    "Number of Redis cache misses",
)

TRANSCODER_LATENCY = Histogram(
    "transcoder_duration_seconds",
    "Time spent in FFmpeg transcoder",
    buckets=[5, 10, 30, 60, 120, 300],
)

SCRAPER_ERRORS = Counter(
    "scraper_errors_total",
    "Scraper failures by provider",
    ["provider"],
)
