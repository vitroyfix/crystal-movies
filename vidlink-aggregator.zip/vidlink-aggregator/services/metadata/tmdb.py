import httpx
from functools import lru_cache
from config.settings import Settings

_BASE = "https://api.themoviedb.org/3"


@lru_cache()
def _settings() -> Settings:
    return Settings()


class TMDB:
    """Async wrapper around the TMDB v3 REST API."""

    @staticmethod
    async def _get(path: str, **params) -> dict:
        params["api_key"] = _settings().tmdb_key
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{_BASE}{path}", params=params)
            r.raise_for_status()
            return r.json()

    @staticmethod
    async def get_movie(tmdb_id: int) -> dict:
        data = await TMDB._get(f"/movie/{tmdb_id}")
        return {
            "title": data["title"],
            "year": (data.get("release_date") or "")[:4],
            "overview": data.get("overview", ""),
            "poster": f"https://image.tmdb.org/t/p/w500{data.get('poster_path') or ''}",
            "tmdb_id": tmdb_id,
            "type": "movie",
        }

    @staticmethod
    async def get_tv(tmdb_id: int, season: int = 1, episode: int = 1) -> dict:
        data = await TMDB._get(f"/tv/{tmdb_id}")
        return {
            "title": data["name"],
            "year": (data.get("first_air_date") or "")[:4],
            "overview": data.get("overview", ""),
            "poster": f"https://image.tmdb.org/t/p/w500{data.get('poster_path') or ''}",
            "tmdb_id": tmdb_id,
            "season": season,
            "episode": episode,
            "type": "tv",
        }
