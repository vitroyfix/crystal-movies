import httpx
from functools import lru_cache
from config.settings import Settings

_BASE = "https://api.myanimelist.net/v2"


@lru_cache()
def _settings() -> Settings:
    return Settings()


class MAL:
    """Async wrapper around the MyAnimeList v2 API."""

    @staticmethod
    async def _get(path: str, **params) -> dict:
        headers = {"Authorization": f"Bearer {_settings().mal_token}"}
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{_BASE}{path}", headers=headers, params=params)
            r.raise_for_status()
            return r.json()

    @staticmethod
    async def get_anime(mal_id: int) -> dict:
        data = await MAL._get(
            f"/anime/{mal_id}",
            fields="title,start_date,synopsis,main_picture",
        )
        year = (data.get("start_date") or "")[:4]
        poster = (data.get("main_picture") or {}).get("large", "")

        return {
            "title": data["title"],
            "year": year,
            "overview": data.get("synopsis", ""),
            "poster": poster,
            "mal_id": mal_id,
            "type": "anime",
        }
