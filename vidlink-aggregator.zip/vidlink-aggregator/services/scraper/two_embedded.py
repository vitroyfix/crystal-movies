"""
TwoEmbedded scraper.

How it works:
  1. Launch a headless Chromium browser via Playwright.
  2. Register a request-interception listener BEFORE navigating.
  3. Navigate to the embed page — the JS player runs automatically.
  4. The player calls its own backend to get the stream URL.
  5. We capture that URL from the intercepted network requests.
  6. Return it as a source dict.

This is the standard technique for any JS-rendered embed page.
"""
import asyncio
from urllib.parse import urlencode
from playwright.async_api import async_playwright, Request as PlaywrightRequest
from api.middleware.anti_bot import random_user_agent
from services.utils.metrics import SCRAPER_ERRORS

PROVIDER = "2embed"
EMBED_BASE = "https://www.2embed.cc/embed/"
TIMEOUT_MS = 20_000
WAIT_AFTER_LOAD_MS = 6_000


class TwoEmbedded:
    @staticmethod
    async def scrape(title: str, year: str | None) -> list[dict]:
        sources: list[dict] = []
        stream_urls: list[str] = []

        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    user_agent=random_user_agent(),
                    extra_http_headers={"Accept-Language": "en-US,en;q=0.9"},
                )
                page = await context.new_page()

                # ── Intercept every outgoing request ──────────────────
                # We look for .m3u8 URLs — these are HLS stream playlists.
                # The JS player fires this request automatically when it
                # initialises, so we just have to be listening.
                def on_request(request: PlaywrightRequest):
                    url = request.url
                    if ".m3u8" in url or "master" in url.lower():
                        stream_urls.append(url)

                page.on("request", on_request)
                # ──────────────────────────────────────────────────────

                query = urlencode({"title": title, "year": year or ""})
                embed_url = f"{EMBED_BASE}?{query}"

                await page.goto(embed_url, timeout=TIMEOUT_MS, wait_until="networkidle")
                # Extra wait — some players defer their stream request
                await page.wait_for_timeout(WAIT_AFTER_LOAD_MS)

                await browser.close()

        except Exception as e:
            SCRAPER_ERRORS.labels(provider=PROVIDER).inc()
            return []

        for url in stream_urls:
            quality = "1080p" if "1080" in url else "720p"
            sources.append({"provider": PROVIDER, "quality": quality, "url": url})

        return sources
