"""
AutoEmbed scraper — same Playwright interception pattern, different host.
"""
from urllib.parse import quote
from playwright.async_api import async_playwright, Request as PlaywrightRequest
from api.middleware.anti_bot import random_user_agent
from services.utils.metrics import SCRAPER_ERRORS

PROVIDER = "autoembed"
EMBED_BASE = "https://autoembed.co/movie/tmdb/"
TIMEOUT_MS = 20_000
WAIT_AFTER_LOAD_MS = 6_000


class AutoEmbed:
    @staticmethod
    async def scrape(title: str, year: str | None) -> list[dict]:
        sources: list[dict] = []
        stream_urls: list[str] = []

        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    user_agent=random_user_agent(),
                    extra_http_headers={"Accept-Language": "en-US,en;q=0.9"},
                )
                page = await context.new_page()

                # ── Intercept outgoing requests ────────────────────────
                def on_request(request: PlaywrightRequest):
                    url = request.url
                    if ".m3u8" in url or "playlist" in url.lower():
                        stream_urls.append(url)

                page.on("request", on_request)
                # ──────────────────────────────────────────────────────

                embed_url = f"{EMBED_BASE}{quote(title)}"
                await page.goto(embed_url, timeout=TIMEOUT_MS, wait_until="networkidle")
                await page.wait_for_timeout(WAIT_AFTER_LOAD_MS)

                await browser.close()

        except Exception:
            SCRAPER_ERRORS.labels(provider=PROVIDER).inc()
            return []

        for url in stream_urls:
            quality = "1080p" if "1080" in url else "720p"
            sources.append({"provider": PROVIDER, "quality": quality, "url": url})

        return sources
