import asyncio
from services.scraper.two_embedded import TwoEmbedded
from services.scraper.autoembed import AutoEmbed


class ScraperFactory:
    """
    Runs all scrapers concurrently and merges their results.
    return_exceptions=True means one scraper failing does not
    cancel the others — we still get results from the rest.
    """
    _scrapers = [TwoEmbedded, AutoEmbed]

    @staticmethod
    async def scrape(title: str, year: str | None) -> list[dict]:
        tasks = [s.scrape(title, year) for s in ScraperFactory._scrapers]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        sources: list[dict] = []
        for r in results:
            if isinstance(r, list):
                sources.extend(r)
            # exceptions are silently skipped — scraper already
            # incremented its SCRAPER_ERRORS counter

        return sources
