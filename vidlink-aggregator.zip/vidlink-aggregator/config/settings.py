from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    tmdb_key: str = ""
    mal_token: str = ""
    redis_url: str = Field("redis://redis:6379/0")
    aws_bucket: str = ""
    aws_region: str = "us-east-1"
    aws_key: str = ""
    aws_secret: str = ""
    use_r2: bool = False
    r2_account_id: str = ""
    sentry_dsn: str = ""
    environment: str = "prod"

    model_config = SettingsConfigDict(env_file="config/.env", extra="ignore")
