import time
import random
from collections import defaultdict
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request
from fastapi.responses import JSONResponse

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
]

RATE_LIMIT = 60       # requests allowed per window
WINDOW_SECONDS = 60   # sliding window in seconds

# ip -> list of request timestamps within the current window
_request_log: dict[str, list[float]] = defaultdict(list)


class AntiBotMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host
        now = time.time()

        # Evict timestamps outside the sliding window
        _request_log[client_ip] = [
            t for t in _request_log[client_ip] if now - t < WINDOW_SECONDS
        ]

        if len(_request_log[client_ip]) >= RATE_LIMIT:
            return JSONResponse(
                {"detail": "Rate limit exceeded. Try again later."},
                status_code=429,
            )

        _request_log[client_ip].append(now)

        # Store a fresh UA on request state so scrapers can pick it up
        request.state.user_agent = random_user_agent()

        return await call_next(request)


def random_user_agent() -> str:
    """Return a random desktop browser User-Agent string."""
    return random.choice(USER_AGENTS)
