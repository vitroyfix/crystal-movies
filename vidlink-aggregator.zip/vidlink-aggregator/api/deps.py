from functools import lru_cache
from config.settings import Settings
from services.cache.redis import RedisCache
from services.storage.s3 import S3Client


@lru_cache()
def get_settings() -> Settings:
    return Settings()


async def get_cache() -> RedisCache:
    """FastAPI dependency — returns a connected RedisCache instance."""
    settings = get_settings()
    cache = RedisCache(settings.redis_url)
    await cache.connect()
    return cache


async def get_s3() -> S3Client:
    """FastAPI dependency — returns a configured S3Client instance."""
    s = get_settings()
    return S3Client(
        bucket=s.aws_bucket,
        region=s.aws_region,
        key=s.aws_key,
        secret=s.aws_secret,
        use_r2=s.use_r2,
        r2_account_id=s.r2_account_id,
    )
