from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import List

from services.metadata.tmdb import TMDB
from services.metadata.mal import MAL
from services.scraper.base import ScraperFactory
from stream.hls import generate_and_upload_master
from services.cache.redis import RedisCache
from services.storage.s3 import S3Client
from services.utils.metrics import CACHE_HITS, CACHE_MISSES
from .deps import get_cache, get_s3

router = APIRouter()


class StreamRequest(BaseModel):
    id: int
    type: str = Field(..., pattern="^(movie|tv|anime)$")   # bug fix: regex= → pattern= (pydantic v2)


class Source(BaseModel):
    provider: str
    quality: str
    url: str


class StreamResponse(BaseModel):
    metadata: dict
    sources: List[Source]
    master_playlist: str


@router.post("/resolve", response_model=StreamResponse)
async def resolve(
    req: StreamRequest,
    # Bug fix: Depends(lambda: get_cache()) is wrong — the lambda
    # returns a coroutine that FastAPI never awaits properly.
    # Depends(get_cache) is the correct pattern.
    cache: RedisCache = Depends(get_cache),
    s3: S3Client = Depends(get_s3),
):
    key = f"{req.type}:{req.id}"

    cached = await cache.get(key)
    if cached:
        CACHE_HITS.inc()
        return StreamResponse(**cached)

    CACHE_MISSES.inc()

    # 1. Metadata
    if req.type == "movie":
        meta = await TMDB.get_movie(req.id)
    elif req.type == "tv":
        meta = await TMDB.get_tv(req.id)
    else:
        meta = await MAL.get_anime(req.id)

    # 2. Scrape sources
    sources = await ScraperFactory.scrape(meta["title"], meta.get("year"))
    if not sources:
        raise HTTPException(status_code=404, detail="No sources found for this title")

    # 3. Transcode → HLS → S3
    master_url = await generate_and_upload_master(sources, s3)

    # Bug fix: Source(**s).__dict__ is wrong in pydantic v2 — __dict__ includes
    # internal pydantic fields. Use model_dump() or just keep the raw dicts.
    result = {
        "metadata": meta,
        "sources": sources,           # already list[dict] from scrapers
        "master_playlist": master_url,
    }
    await cache.set(key, result, ttl=3600)
    return StreamResponse(**result)


class SubtitleRequest(BaseModel):
    url: str


@router.post("/episodes/{episode_id}/subtitles")
async def store_subtitle(episode_id: int, req: SubtitleRequest, cache: RedisCache = Depends(get_cache)):
    await cache.set(f"sub:{episode_id}", {"url": req.url}, ttl=86400)
    return {"status": "ok"}


@router.get("/episodes/{episode_id}/next")
async def next_episode(episode_id: int):
    # Simple increment — real logic would query TMDB for the next episode
    return {"next_episode_id": episode_id + 1}
