import os
from contextlib import asynccontextmanager

import sentry_sdk
from sentry_sdk.integrations.fastapi import FastAPIIntegration
from fastapi import FastAPI
from fastapi.responses import Response
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

from .router import router
from .deps import get_cache, get_s3
from .middleware.anti_bot import AntiBotMiddleware

# Bug fix: metrics were defined inline in main.py, which means they get
# re-registered on every hot-reload and crash with ValueError.
# They are now imported from the single source of truth.
from services.utils.metrics import REQUESTS

# ── Sentry ────────────────────────────────────────────────────────────────
sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN", ""),
    traces_sample_rate=1.0,
    environment=os.getenv("ENVIRONMENT", "prod"),
    integrations=[FastAPIIntegration()],
)


# ── Lifespan (replaces deprecated @app.on_event) ─────────────────────────
# Bug fix: @app.on_event("startup") is deprecated since FastAPI 0.93.
# The lifespan context manager is the correct approach.
@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    cache = await get_cache()
    app.state.cache = cache
    app.state.s3 = await get_s3()
    yield
    # shutdown
    await cache.close()


# ── App ───────────────────────────────────────────────────────────────────
app = FastAPI(title="Vidlink Aggregator", lifespan=lifespan)

app.add_middleware(AntiBotMiddleware)
app.include_router(router, prefix="/api")


@app.middleware("http")
async def metrics_middleware(request, call_next):
    REQUESTS.labels(endpoint=request.url.path).inc()
    return await call_next(request)


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.get("/health")
def health():
    return {"status": "ok"}
