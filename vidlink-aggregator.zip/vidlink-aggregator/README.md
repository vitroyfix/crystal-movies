# Vidlink-Aggregator

A production-ready microservice that acts as a **resolver/scraper API** — it takes a TMDB or MAL content ID, scrapes stream sources using headless Playwright browsers, transcodes them to adaptive HLS via FFmpeg, stores segments on S3/R2, and returns a master playlist URL ready for any video player.

## Architecture

```
POST /api/resolve {id, type}
        │
        ├── Redis cache hit? → return immediately
        │
        ├── TMDB / MAL  →  fetch title + metadata
        │
        ├── ScraperFactory (concurrent)
        │     ├── TwoEmbedded  (Playwright request interception)
        │     └── AutoEmbed    (Playwright request interception)
        │
        ├── FFmpeg  →  1080p + 720p HLS segments
        │
        ├── S3 / R2  →  upload segments + playlists
        │
        └── Redis  →  cache result for 1 hour
```

## Stack

| Layer | Technology |
|---|---|
| API | FastAPI + Uvicorn |
| Scraping | Playwright (headless Chromium) |
| Transcoding | FFmpeg (libx264 + AAC) |
| Streaming format | HLS (master + variant playlists) |
| Cache | Redis (aioredis) |
| Storage | AWS S3 or Cloudflare R2 |
| Background jobs | Celery |
| Observability | Sentry + Prometheus |
| Testing | pytest + pytest-asyncio + moto |

## Quick Start

```bash
# 1. Copy env file and fill in your keys
cp config/.env.example config/.env

# 2. Start all services
docker compose up --build

# 3. Resolve a movie (The Matrix = TMDB ID 603)
curl -X POST http://localhost:8000/api/resolve \
  -H "Content-Type: application/json" \
  -d '{"id": 603, "type": "movie"}'
```

## Endpoints

| Method | Path | Description |
|---|---|---|
| POST | `/api/resolve` | Resolve movie / TV / anime to HLS master playlist |
| POST | `/api/episodes/{id}/subtitles` | Store a subtitle URL for an episode |
| GET  | `/api/episodes/{id}/next` | Get the next episode ID |
| GET  | `/metrics` | Prometheus metrics |
| GET  | `/health` | Health check |

## Environment Variables

| Variable | Description |
|---|---|
| `TMDB_KEY` | TMDB v3 API key (free at themoviedb.org) |
| `MAL_TOKEN` | MyAnimeList OAuth2 bearer token |
| `REDIS_URL` | Redis connection URL |
| `AWS_BUCKET` | S3 bucket name |
| `AWS_REGION` | AWS region |
| `AWS_KEY` | AWS access key ID |
| `AWS_SECRET` | AWS secret access key |
| `USE_R2` | Set to `True` to use Cloudflare R2 instead of S3 |
| `R2_ACCOUNT_ID` | Cloudflare account ID (required if USE_R2=True) |
| `SENTRY_DSN` | Sentry DSN for error tracking |
| `ENVIRONMENT` | `dev` or `prod` |

## Running Tests

```bash
pip install -r test_requirements.txt
pytest tests/ -v --asyncio-mode=auto
```

## MinIO (local S3)

The docker-compose setup includes MinIO as a local S3-compatible store.
Access the web console at http://localhost:9001 (user: `minio`, pass: `minio123`).
Create a bucket named `vidlink-bucket` before your first resolve request.

## Production Notes

- Replace MinIO with real S3 or Cloudflare R2.
- Use Kubernetes with horizontal pod autoscaling for the API and worker.
- The FFmpeg transcoder is CPU-intensive — run workers on compute-optimised instances.
- Set `ENVIRONMENT=prod` to enable Sentry production alerting.
