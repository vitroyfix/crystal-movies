"""
Celery worker for background scrape jobs.

Bug fix: the original used cache.connect() / cache.get() / cache.set()
synchronously inside a Celery task, but RedisCache is fully async.
Fixed by using the synchronous redis-py client directly inside the
Celery task (Celery tasks run in a regular synchronous thread pool,
not an asyncio event loop).
"""
import os
import json
import asyncio

import sentry_sdk
from sentry_sdk.integrations.celery import CeleryIntegration
from celery import Celery

from config.settings import Settings

sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN", ""),
    traces_sample_rate=1.0,
    integrations=[CeleryIntegration()],
    environment=os.getenv("ENVIRONMENT", "prod"),
)

_settings = Settings()
celery = Celery("scraper", broker=_settings.redis_url, backend=_settings.redis_url)


@celery.task(bind=True, max_retries=3, default_retry_delay=10)
def scrape_job(self, title: str, year: str):
    """
    Background task: scrape sources for a title and cache them.
    Uses asyncio.run() to drive the async scrapers from a sync Celery task.
    """
    import redis as redis_sync
    from services.scraper.base import ScraperFactory

    r = redis_sync.from_url(_settings.redis_url, decode_responses=True)
    key = f"src:{title}:{year}"

    cached = r.get(key)
    if cached:
        return json.loads(cached)

    try:
        # Drive async scrapers from the sync Celery context
        sources = asyncio.run(ScraperFactory.scrape(title, year))
    except Exception as exc:
        raise self.retry(exc=exc)

    r.setex(key, 86400, json.dumps(sources))
    return sources
