"""
HLS pipeline: pick best source → transcode → upload to S3 → return master URL.
"""
import os
import time
import tempfile

from services.transcoder.ffmpeg import transcode_to_hls
from services.storage.s3 import S3Client
from services.utils.metrics import TRANSCODER_LATENCY


async def generate_and_upload_master(
    sources: list[dict],
    s3: S3Client,
) -> str:
    """
    1. Pick the highest-quality source.
    2. Transcode to multi-bitrate HLS in a temp directory.
    3. Upload every .m3u8 and .ts file to S3.
    4. Return the public URL of master.m3u8.
    """
    if not sources:
        raise ValueError("No sources available to transcode")

    # Prefer 1080p; fall back to the first available source
    best = next((s for s in sources if s.get("quality") == "1080p"), sources[0])
    source_url = best["url"]

    with tempfile.TemporaryDirectory() as tmp:
        t0 = time.perf_counter()
        master_local = await transcode_to_hls(source_url, tmp)
        TRANSCODER_LATENCY.observe(time.perf_counter() - t0)

        master_url = _upload_hls_dir(tmp, s3)

    return master_url


def _upload_hls_dir(local_dir: str, s3: S3Client) -> str:
    """
    Walk the HLS output directory, upload every file, and return
    the public URL of master.m3u8.
    """
    prefix = f"hls/{int(time.time())}"
    master_url = ""

    for root, _, files in os.walk(local_dir):
        for fname in sorted(files):
            local_path = os.path.join(root, fname)
            relative = os.path.relpath(local_path, local_dir)
            s3_key = f"{prefix}/{relative}"

            content_type = (
                "application/x-mpegURL"
                if fname.endswith(".m3u8")
                else "video/MP2T"
            )
            url = s3.upload_file(local_path, s3_key, content_type)

            if fname == "master.m3u8":
                master_url = url

    if not master_url:
        raise RuntimeError("master.m3u8 was not found in the HLS output")

    return master_url
